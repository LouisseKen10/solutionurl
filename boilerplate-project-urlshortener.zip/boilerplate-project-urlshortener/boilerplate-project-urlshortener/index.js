require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const dns = require('dns');
const cors = require('cors');
const app = express();

const port = process.env.PORT || 3000;

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Mongo connected'))
  .catch(err => console.error(err));

const urlSchema = new mongoose.Schema({
  original_url: { type: String, required: true },
  short_url: { type: Number, required: true, unique: true }
});
const Url = mongoose.model('Url', urlSchema);

app.use(cors());
app.use(express.urlencoded({ extended: false }));
app.use('/public', express.static(`${process.cwd()}/public`));

app.get('/', function (req, res) {
  res.sendFile(process.cwd() + '/views/index.html');
});

app.post('/api/shorturl', (req, res) => {
  const original = req.body.url;

  let hostname;
  try {
    const parsed = new URL(original);
    if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error();
    hostname = parsed.hostname;
  } catch {
    return res.json({ error: 'invalid url' });
  }

  dns.lookup(hostname, async (err) => {
    if (err) return res.json({ error: 'invalid url' });

    let doc = await Url.findOne({ original_url: original });
    if (!doc) {
      const count = await Url.countDocuments();
      doc = await Url.create({ original_url: original, short_url: count + 1 });
    }
    res.json({ original_url: doc.original_url, short_url: doc.short_url });
  });
});

app.get('/api/shorturl/:short_url', async (req, res) => {
  const doc = await Url.findOne({ short_url: Number(req.params.short_url) });
  if (!doc) return res.json({ error: 'No short URL found' });
  res.redirect(doc.original_url);
});

app.listen(port, function () {
  console.log(`Listening on port ${port}`);
});